#include <GL/glut.h>
#include <GL/gl.h>
#include <GL/glu.h>
void toCameraMatrix(GLfloat* transform_mat , GLfloat* camera_mat);